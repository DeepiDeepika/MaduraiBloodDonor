<?php
include "./header8.php";
?>
<br><br>
<br>
<br>
<br>
<br>

   <section>
       
        <div align='center'>

<?php
session_start();
?>
<?php
if(isset($_SESSION['user'])) {
include("db.php");
$id=$_SESSION['user'];
$rs=mysql_query("select * from donorissued where donorid=$id") or die(mysql_error());
if(mysql_num_rows($rs)>0) {
$r=mysql_fetch_array($rs);
echo "<center>You have issued blood last on '$r[2]'</center>";
echo "<center>You can issued blood once on or after '$r[3]'</center>";
echo "<center>Thank You</center>";
}
else
echo "<center><h1>Dear User You can Issue <font color='red'>Blood</font> Now</h1></center>";
}
else
echo "<hr><h3 align='center'>You are Not Authorized to view the page</h3><hr>";
?>
</div>
</section>
</body>
</html>