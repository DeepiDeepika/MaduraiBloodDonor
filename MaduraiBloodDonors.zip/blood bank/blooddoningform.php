<?php
include "./adminpage.php";
?>
<br><br>
<br>
<br>
<br>
<br>

   <section >        
        <div align='center'>

<style>
.alnr{text-align:right}
</style>
<script type="text/javascript">
function show(arg) {
if(arg!="") {
if(window.XMLHttpRequest)
ob=new XMLHttpRequest()
else
ob=new ActiveXObject("Microsoft.XMLHTTP")
ob.onreadystatechange=function() {
if(ob.readyState==4&&ob.status==200) {
document.getElementById("d").innerHTML=ob.responseText
}
}
ob.open("GET","getnewuser.php?z="+arg,true)
ob.send()
}
else
document.getElementById("d").innerHTML=""
}
function check() {
id=f.t1.value
if(id=="") {
alert("Id should not be Empty")
return false
}
return true
}
</script>
<?php
if(isset($_SESSION['user']) && $_SESSION['user']=="admin") {
include("db.php");
$dt=date('Y-m-d',time());
$rs=mysql_query("select userid from newuser where userid not in (select donorid from donorissued where nextissue is not null and nextissue > '$dt')") or die(mysql_error());
if(!isset($_GET['submit'])) {
?>
<form name="f" action="blooddoningform.php" method="get" onsubmit="return check()">
<table align="center">
<tr>
<td class="alnr">Select the Donor Id</td>
<td>
<select name="t1" onchange="show(this.value)">
<option value=""></option>
<?php
while($r=mysql_fetch_array($rs))
echo "<option value=$r[0]>$r[0]</option>";
?>
</select>
</td>
</tr>
<tr>
<td class="alnr">Donor Name<br>&<br>Blood Type</td>
<td><div id="d"></div></td>
</tr>
<tr>
<td class="alnr">Doning Date</td>
<td><input type="text" name="t2" value="<?php echo $dt;?>" readonly></td>
</tr>
<tr>
<td class="alnr">Unit Doned</td>
<td><input type="text" name="t3" value="1" readonly></td>
</tr>
<tr>
<td colspan="2" align="center"><input type="submit" value="SUBMIT" name="submit"></td>
</tr>
<tr>
<td colspan="2" align="center">New Donor? <a href="newuser.php">Register First</a></td>
</tr>
</table>
</form>
<?php
}
else if(isset($_GET['submit'])) {
	$id=$_GET['t1'];
	$name=$_GET['a1'];
	$group=$_GET['a2'];
	$ddate=$_GET['t2'];
	$unit=$_GET['t3'];
	mysql_query("insert into bloodstore (donorid,donorname,bloodgroup,doningdate,units) values ($id,'$name','$group','$ddate',$unit)") or die(mysql_error());
	mysql_query("insert into donorissued values ($id,'$name','$ddate',date_add('$ddate',interval 180 day))") or die(mysql_error());
	header('Location:blooddoningform.php');
}
}
else
echo "<hr><h3 align='center'>You are Not Authorized to view the page</h3><hr>";
?>
</section>
</div>
</body>
</html>