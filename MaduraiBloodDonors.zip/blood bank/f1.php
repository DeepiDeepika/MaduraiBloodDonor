<html>
<body>
<section>
<div class="footer-mein">
    <div class="contaier" >
        <div class="row">
            <div class="col-md-5">
                <div class="footer-social">
                    
      <div class="col-md-4">
        <div class="contact-text">
            <h1>Contact Us</h1>
            <h2><i class="fa fa-map-marker" aria-hidden="true"></i></i> &nbsp; Address</h2>
            <p>Masjid Tawheed,</p>
            <p>No.1 Gandhi Nagar Cross Street,</p>
            <p>Anna Bus stand Backside,</p>
            <p>Madurai-625001.</p>
             <h2><i class="fa fa-phone-square" aria-hidden="true"></i> &nbsp; Phone</h2>
            <p>+91 978 934 1714</p>
            <h2><i class="fa fa-envelope" aria-hidden="true"></i> &nbsp; E-mail</h2>
            <p>jaqhmadurai@gmail.com</p>
        </div>
      </div>
                </div>
            </div>
            
        </div>
    </div>
</div>
<div class="footer-bottom">
  <div class="container">
     <p>                      All Rights Reserved @2022 MaduraiBloodDonors.com           <span class="pull-right"><a href=""></a></span></p>

  </div>
</div>
</section>
</body>
</html>
<style>
.footer{
    width: 100%;
    height: auto;
    background-color: #DC143C;
    padding: 40px 0;
}
.footer-inner{
    width: 100%;
    height: auto;
    background: #fff;
    padding: 24px;
}
.footer-mein{
    width: 100%;
    height:auto;
    background: #cc0000;
    padding: 30px 0;
}
.contact-text{
    width: 100%;
    height: auto;
}
.contact-text h1{
    font-size: 36px;
    font-weight: 600;
    color: #cc0000; 
    margin: 0;
    padding-bottom: 20px;
}
.contact-text h2{
    font-size: 20px;
    font-weight: 500;
    color: #444;
    margin: 0;
    padding-top: 25px;
}
.contact-text h2 i {
     color:#cc0000;
}
.contact-text p{
     font-size: 14px;
     color: #000;
     margin: 0;
     padding-top: 5px;
     padding-left: 24px;
     font-weight: 100;
}
.footer-social{
    width: 100%;
    height:auto;
}
.footer-social h3{
    font-size: 36px;
    font-weight: 500;
    color: #fff;
    margin: 0;
}
.footer-social h3 span{
     font-size: 18px;
    font-weight: 200;
}
.footer-bottom{
    width: 100%;
    height: auto;
    margin: auto;
    background: #272727;
}
.footer-bottom p{
    font-size: 14px;
    color: white;
    font-weight: 100;
    margin: 0;
    padding: 8.5px 0;
    text-decoration: none;
}
.footer-bottom p span{
   font-size: 14px;
}
.footer-bottom p span{
    font-size: 14px;
 }.footer-bottom p a{
     color: white;
     text-decoration: none;
 }
</style>