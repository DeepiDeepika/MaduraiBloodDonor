<html>
<?php
session_start();
if(isset($_SESSION['user']) && $_SESSION['user']=="admin") {
?>
<?php
include "./header.php";
?>
<br><br>
<br>
<br>
<br>
<br>

   <section >

        
        <div align='center'>

<frameset rows="30%,*" border="0">
<frame src="adminpage.php">
<frame name="bottom">
</frameset>
<?php
}
else
echo "<hr><h3 align='center'>You are Not Authorized to view the page</h3><hr>";
?>
</div>
</section>
</html>