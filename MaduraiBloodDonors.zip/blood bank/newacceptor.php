<?php
include "./header.php";
include "./db.php";
?>
<br>
<br>
<br>
<section>
<div>
<?php
if(!isset($_POST['submit'])) {
?>
<section>
<div align='center'>
<div class="Acceptor Registration">
 <form name="f" action="" method="post">
 <label>Name</label><br>
 <input type="text" name="name" required/><br>
 

 <label>Address</label><br>
 <textarea name="addr" required></textarea><br>
 

 <label>City</label><br>
 <input type="text" name="city" required><br>
 

 <label>Mobile Number</label><br>
 <input type="text" name="mobile" pattern="\d{10}" maxlength="10" required><br>
 

 <label>User Id</label><br>
 <input type="text" name="userid" required><br>
 

 <label>Password</label><br>
 <input type="text" /><br>
 <br>
<br>

 <input type="submit" name="submit" value="Register">

 </form>
</div>

<?php
} else {
	extract($_POST);
	mysql_query("insert into acceptor (name,addr,city,mobile,userid,pwd) values ('$name','$addr','$city','$mobile','$userid','$pwd')") or die(mysql_error()."<br><a href='newacceptor.php'>Back</a>");
	echo "<br><center>Acceptor Created...<br><a href='photogallery.php'>Login</a></center>";
}
?>
</div>
</section>
</body>
<style>

.registration form{
 width:300px;
 height:400px;
 background-color: #566573;
 padding: 10px 0px 0px 4px;
 border-radius: 15px;
 color: white;
 text-transform: uppercase;
 font-size: 11px;
 font-weight: bold;
 font-family: "Century Gothic";
}

.registration input, .registration select{
 width: 195px;
 height: 20px;
 margin: 3px 0px 0px 10px;
 border: 0px;
 font-weight: bold;
 
}

.registration input:focus{
 background-color: orange;
}

.registration form label{
 margin: 5px 0px 0px 15px;
}

a{
 outline:none;
}

.register_button{
 width: 140px;
 height: 42px;
 background-color: orange;
 margin: 15px auto 0px auto;
 text-align: center;
 cursor: pointer;
 clear: both;
 border-radius: 10px;
 
}

.register_button span{
 font-weight: normal;
 font-size: 28px;
 font-family: "Impact";
 line-height: 40px;
}
.register_button span a{
 text-decoration: none;
 color: white;
}
.register_button span a:hover{
 color: black;
}



p.error{
 margin:0px 14px 0px 10px;
 font-size:9px;
 color:orange;
 height:6px;
 padding: 0px 0px 8px 0px;
 text-align:right;
 text-transform:none;
}

</style>
</html>