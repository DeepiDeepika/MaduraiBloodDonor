<?php
include("db.php");
	$id=$_GET['z'];
$rs=mysql_query("select name,blood from newuser where userid=$id") or die(mysql_error());
$r=mysql_fetch_array($rs);
echo "<input type='text' name='a1' value='$r[0]' readonly><br>";
echo "<input type='text' name='a2' value='$r[1]' readonly>";
	
?>