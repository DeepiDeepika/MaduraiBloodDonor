         <?php
include "./header.php";
?>
<br><br>
<br>

   <section >


        
        <div align='center'>

   <h1 align='center' style='color:white;font-family:MS Sans Serif;font-size:40px;'><b>MADURAI BLOOD DONORS</b></h1>

<br><br><br><br>
        <div class="box">
    <a class="button" href="#popup1">MISSION</a>
    <a class="button" href="#popup2">VISION</a>
</div>

<div id="popup1" class="overlay">
    <div class="popup">
        <h2>MISSION</h2>
        <a class="close" href="#">&times;</a>
        <div class="content">
            To enhance the well being of patients in our service area by assuring a reliable and 
            economical supply of the safest possible blood, by providing innovative hemotherapy services, 
            and by promoting research and education programs in transfusion medicine.
        </div>
    </div>
</div>
<div id="popup2" class="overlay">
    <div class="popup">
        <h2>VISION</h2>
        <a class="close" href="#">&times;</a>
        <div class="content">
            Blood Center will be recognized for saving and improving lives in our community with safe and reliable blood. A Centre of Excellence in Blood Banking, Committed to Safe and High Quality Blood for Children, free of cost , thereby enabling them an opportunity for a normal and holistic life.

        </div>
    </div>
</div>

</section>

<style>
 .box {
    width: 40%;
    margin: 0 auto;
    background: rgba(255,255,255,0.2);
    padding: 35px;
    border: 2px solid #fff;
    border-radius: 20px/50px;
    background-clip: padding-box;
    text-align: center;
  }
  
  .button {
    font-size: 1em;
    padding: 10px;
    color: #fff;
    border: 1px solid #fff;
    border-radius: 20px/50px;
    text-decoration: none;
    cursor: pointer;
    transition: all 0.3s ease-out;
  }
  .button:hover {
    background: #fff;
    color:#000;
  }
  
  .overlay {
    position: fixed;
    top: 250 px; 
    bottom: 0;
    left: 0;
    right: 0;
    margin:0 auto;
    transition: opacity 500ms;
    visibility: hidden;
    opacity: 0;
  }
  .overlay:target {
    visibility: visible;
    opacity: 1;
  }
  
  .popup {
    margin: 70px auto;
    padding: 50px;
    background: #fff;
    border-radius: 25px;
    width: 90%;
    position: relative;
    transition: all 5s ease-in-out;
  }
  
  .popup h2 {
    margin-top: 0;
    color: #333;
    font-family: Tahoma, Arial, sans-serif;
    text-align:center;
  }
  .popup .close {
    position: absolute;
    top: 20px;
    right: 30px;
    transition: all 200ms;
    font-size: 30px;
    font-weight: bold;
    text-decoration: none;
    color: #333;
  }
  .popup .close:hover {
    color: #000;
  }
  .popup .content {
    max-height: 30%;
    overflow: auto;
  }
</style>
</body>
</html>
<br>
<br>
<br>
<br><br>
<br>
<br>
<br>
<br>
<?php
include "./footer.php";
?>  

