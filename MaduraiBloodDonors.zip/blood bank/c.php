<?php
include "./header7.php";
?>
<html lang="en">
<head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
          <title>Contact & Location </title>
        <link rel="stylesheet" type="text/css" href="c.css">
        <script src="https://kit.fontawesome.com/a076d05399.js"></script>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css" crossorigin="anonymous">
        <style>
          div.scroll{
      Width: 100%;
      Height:10px;
      Overflow-x:scroll;
      }
          </style>
      
      </head>
<body>
<div class="footer">
<br>
<br>
 <div class="container">
  <div class="footer-inner">
    <div class="row">
      <div class="col-md-8">
        <div class="map">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3930.116691093775!2d78.13456631411047!3d9.924238677058767!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3b00c5a32bde0343%3A0x766105d545d12065!2s1%2C%20Gandhi%20Nagar%20Cross%20St%2C%20Mathichiyam%2C%20Ranan%20Nagar%2C%20Madurai%2C%20Tamil%20Nadu%20625020!5e0!3m2!1sen!2sin!4v1647439012375!5m2!1sen!2sin" width="100%" height="auto" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
        </div>
      </div>
      <div class="col-md-4">
        <div class="contact-text">
            <h1>Contact Us</h1>
            <h2><i class="fa fa-map-marker" aria-hidden="true"></i></i> &nbsp; Address</h2>
            <p>Masjid Tawheed,</p>
            <p>No.1 Gandhi Nagar Cross Street,</p>
            <p>Anna Bus stand Backside,</p>
            <p>Madurai-625001.</p>
             <h2><i class="fa fa-phone-square" aria-hidden="true"></i> &nbsp; Phone</h2>
            <p>+91 978 934 1714</p>
            <h2><i class="fa fa-envelope" aria-hidden="true"></i> &nbsp; E-mail</h2>
            <p>jaqhmadurai@gmail.com</p>
        </div>
      </div>
     </div>
    </div>
 </div>
</div>
<div class="footer-mein">
    <div class="contaier" >
        <div class="row">
            <div class="col-md-5">
                <div class="footer-social">
                    <marquee behavior="alternate"  direction="right" scrollamount="12"><h3>KEEP ME INFORMED</h3></marquee>
                </div>
            </div>
            
        </div>
    </div>
</div>
<div class="footer-bottom">
  <div class="container">
     <p>                       All Rights Reserved @2022 MaduraiBloodDonors.com           <span class="pull-right"><a href=""></a></span></p>
  </div>
</div>
</body>
</html>
