<?php
session_start();
?>
<?php
include "./header.php";
?>
<html>
<head>

   <section >
<link rel="stylesheet" a href="adminlogin.css"/>
<div align='center'>
<title>Admin Login</title>

</head>
<body>
  <div class="container">
  <img src="ai.jpg"/>
  <form action="adminlogin.php" method="post">
<div class="form-input">
<input type="text" name="t1" placeholder="Username"/>
</div>
<div class="form-input">
<input type="password" name="t2" placeholder="Password"/>
</div>
<input type="submit" name="submit" value="Administrator Login" class="btn-login">
</form>
<?php
if(isset($_POST['submit'])) {
if(!empty($_POST['t1']) && !empty($_POST['t2'])) {
	$un=$_POST['t1'];
	$pw=$_POST['t2'];

	if($un=="admin" && $pw=="admin") {
	$_SESSION['user']=$un;
	header('Location:adminpage.php');
	}
	else {
	header('Location:adminlogin.php');
	}
}
}
?>
</section>
</div>   
</body></html>