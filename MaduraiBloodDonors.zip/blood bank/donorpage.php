<?php
include "./header2.php";
?>
<html>
<head>
       <meta charset="utf-8">
       <meta name="viewport" content="width=device-width, initial-scale=1.0">
       <link rel="stylesheet" type="text/css" href="abt.css">  
       <script src="https://kit.fontawesome.com/64d58efce2.js" ></script>
       <script src="https://kit.fontawesome.com/a076d05399.js"></script>
       <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
       <script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.min.js"></script>
       <script src="https://cdnjs.cloudflare.com/ajax/libs/Counter-Up/1.0.0/jquery.counterup.min.js"></script>
             <title>Donor Login</title>

</head>
<style>
        *{
     margin: 0px;
     padding: 0px;
     box-sizing: border-box;
     font-family: 'Josefin Sans',sans-serif;
}
.wrapper{
      padding: 20px 50px;
}
.wrapper .title{
     font-size: 40px;
     font-weight: 600;
     text-align: center;
     margin-bottom: 10px; 
}
.wrapper p{
     text-align: justify;
     padding-bottom: 20px;
}
.counter-up{
      background: url("count.png") no-repeat;
      min-height: 50vh;
      display: flex;
      align-items: center;
      padding: 0 50px;
      background-size: cover;
      background-attachment: fixed;
      position: relative;
}
.counter-up::before{
       position: absolute;
       content: "";
       top: 0;
       left: 0;
       height: 100%;
       width: 100%;
      
}
.counter-up .content{
      position: relative;
      z-index: 2;
      display: flex;
      width: 100%;
      height: 100%;
      flex-wrap: wrap;
      align-items: center;
      justify-content: space-between;
}
.content .box{
      width: calc(25% - 30px);
      border: 1px dashed  white;
      border-radius: 5px;
      padding: 20px;
      display: flex;
      align-items: center;
      justify-content: space-evenly;
      color: black;
      flex-direction: column;
      border-radius: 5px;
      }
.content .box .icon{
      font-size: 48px;
      color:  white;
}
.content .box .counter{
       font-size: 50px;
       color:  white;
       font-weight: 500;
       font-family: sans-serif;
}
.content .box .text{
       color: white;
       font-size: 20px;
       font-weight: 400;
}
@media(max-width: 1036px){
.counter-up{
      padding: 50px 50px 0 50px;
}
.content .box{
      width: calc(50% - 30px);
       margin-bottom: 50px;
}
}
@media(max-width: 580px){
.content .box{
      width: 100%;
}
}

</style>
<body>
      <header>
<?php
session_start();
if(isset($_SESSION['user'])) {
?>


      <div class="main">
           
            <div class="nav-btn">
              <div class="nav-links">
                  <ul>
                      <li class="nav-link" style="--i: .6s">
                          <a href="usernotify.php">User Notification</a>
                      </li>
                      <li class="nav-link" style="--i: .6s">
                          <a href="logout.php">Logout</a>
                      </li>
                    </ul>
                </div>
            </div>
            <div class="wrapper">
                <div class="title"></div>
<br>
<br>
<br>
              </div>
         <div class="counter-up">
                  <div class="content">
                          <div class="box">
                                  <div class="icon"><i class="fas fa-history"></i></div>
                                  <div class="counter">24</div>
                                  <div class="text">Working Hours</div>
                          </div>
                           <div class="box">
                                  <div class="icon"><i class="fa fa-users"></i></div>
                                  <div class="counter">199 </div>
                                  <div class="text">Total Donors</div>
                          </div>
                          <div class="box">
                                  <div class="icon"><i class="fa fa-spinner fa-spin"></i></div>
                                  <div class="counter">5</div>
                                  <div class="text">Total Requests</div>
                          </div>
                          <div class="box">
                                  <div class="icon"><i class="fa fa-check-circle"></i></div>
                                  <div class="counter">3</div>
                                  <div class="text">Approved Requests</div>
                          </div>
                 </div>
         </div>
               <script>
                         $(document).ready(function(){
                               $(".counter").counterUp({
                                         delay: 10,
                                         time: 1200
                                      });
                              });
                 </script>
               <?php
}
else {
echo "<hr><h3 align='center'>You are Not Authorized to view the page</h3><hr>";

}
?>
</section>
</div>
</body>
</html>