<?php
session_start();
?>
<html>
<style>
.alnr{text-align:right;}
</style>
<script type="text/javascript">
function call(arg) {
if(arg!="") {
if(window.XMLHttpRequest)
ob=new XMLHttpRequest()
else
ob=new ActiveXObject("Microsoft.XMLHTTP")
ob.onreadystatechange=function() {
if(ob.readyState==4&&ob.status==200) {
document.getElementById("d").innerHTML=ob.responseText
}
}
ob.open("GET","gethospital.php?z="+arg,true)
ob.send()
}
else
document.getElementById("d").innerHTML=""
}
function check() {
id=f.t1.value
bgp=f.t3.value
unit=f.t4.value
if(id==""||bgp==""||unit=="") {
alert("Fields should not be empty")
return false
}
return true
}
</script>
<body background="the blood alliance_files/footer.gif" style="background-repeat:no-repeat;background-position:bottom;">
<?php
if(isset($_SESSION['user'])) {
include("db.php");
$h=$_SESSION['user'];
$dt=date('Y-m-d',time());
$rs=mysql_query("select hid,name from hospital where hid=$h") or die(mysql_error());
$r=mysql_fetch_array($rs);
if(!isset($_GET['submit'])) {
?>
<form name="f" action="bloodrequest.php" method="get" onsubmit="return check()">
<table align="center">
<tr>
<td class="alnr">Hospital Id</td>
<td><input type="text" name="t1" value="<?php echo $r[0];?>" readonly></td>
</tr>
<tr>
<td class="alnr">Hospital Name</td>
<td><input type="text" name="a1" value="<?php echo $r[1];?>" readonly></div></td>
</tr>
<tr>
<td class="alnr">Request Date</td>
<td><input type="text" name="t2" value="<?php echo $dt;?>" readonly></td>
</tr>
<tr>
<td class="alnr">Required BloodGroup</td>
<td>
<select name="t3">
<option value="">Select</option>
<option value="o+">O+
<option value="o-">O-
<option value="ab+">AB+
<option value="ab-">AB-
<option value="ab1+">AB1+
<option value="ab1-">AB1-
<option value="ab2+">AB2+
<option value="ab2-">AB2-
<option value="a1+">A1+
<option value="a1-">A1-
<option value="a2+">A2+
<option value="a2-">A2-
<option value="b+">B+
<option value="b-">B-
</select>
</td>
</tr>
<tr>
<td class="alnr">Units Needed</td>
<td><input type="text" name="t4"></td>
</tr>
<tr>
<td colspan="2" align="center"><input type="submit" name="submit" value="REQUEST"></td>
</tr>
</table>
</form>
<?php
}
else {
	$hid=$_GET['t1'];
	$hname=$_GET['a1'];
	$reqdate=$_GET['t2'];
	$blg=$_GET['t3'];
	$units=$_GET['t4'];
	mysql_query("insert into bloodrequest (hid,hname,reqdate,bloodgroup,requnit) values($hid,'$hname','$reqdate','$blg',$units)") or die(mysql_error());
	header('Location:bloodrequest.php');
}
}
else {
echo "<hr><h3 align='center'>You are Not Authorized to view the page</h3><hr>";
}
?>
</body>
</html>