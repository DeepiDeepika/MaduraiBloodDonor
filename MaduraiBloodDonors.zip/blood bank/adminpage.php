<?php
session_start();
?>
<?php
if(isset($_SESSION['user']) && $_SESSION['user']=="admin") {
?>

<html >
<head>
       <meta charset="utf-8">
       <meta name="viewport" content="width=device-width, initial-scale=1.0">
       <link rel="stylesheet" type="text/css" href="abt.css">  
       <script src="https://kit.fontawesome.com/64d58efce2.js" ></script>
      <title> Admin Page </title>

</head>
<body >
      <header>
      <div class="main">
            <div class="logo">
            <img src="logo.png">
            </div>
            <div class="nav-btn">
              <div class="nav-links">
                  <ul>
                      
                      <li class="nav-link" style="--i: .6s">
                          <a href="blooddoningform.php">Blood Donation</a>
                      </li>
                       <li class="nav-link" style="--i: .6s">
                          <a href="supplytoacceptor.php">Supply to Acceptor</a>
                      </li>
 <li class="nav-link" style="--i: .6s">
                          <a href="logout.php">Logout</a>
                      </li>
 
                      
                    </ul>
                </div>
            </div>


<?php
}
else {
echo "<hr><h3 align='center'>You are Not Authorized to view the page</h3><hr>";
}
?>
</body>
</html>