
<?php
include "./adminpage.php";
?>
<br><br>
<br>
<br>
<br>
<br>

   <section >

        
        <div align='center'>
<?php
include("db.php");
if(!isset($_POST['submit']) && !isset($_POST['submit1'])) {
	$rs = mysql_query("select id from acceptorreq where requnit-issunit>0") or die(mysql_error());
?>
<form name="f" action="" method="post">
<table align="center">
<tr>
<th><h1>Select Request Id</h1>
<td>
<select name="rid" required>
<?php
	while($r = mysql_fetch_row($rs)) {
	echo "<option value=$r[0]>$r[0]</option>";
	}	
?>
</select>
<tr>
<th colspan="2"><input type="submit" name="submit" value="Fetch">
</table>
</form>
<?php
} else if(isset($_POST['submit']) && !isset($_POST['submit1'])) {
	$rid = $_POST['rid'];
	$rs = mysql_query("select name,bgroup,requnit-issunit,id from acceptorreq r,acceptor a where r.userid=a.userid and id=$rid");
	$row = mysql_fetch_row($rs);
	echo "<table align='center' border='1'><tr><th>Name<th>Bloodgroup<th>Unit Requested";
	echo "<tr><td>$row[0]<td>$row[1]<td>$row[2]</table><hr>";

	$rs1 = mysql_query("select tranid,donorname,units from bloodstore where bloodgroup='$row[1]' and issued='no'") or die(mysql_error());
	if(mysql_num_rows($rs1)>0) {
	echo "<form name='f' action='' method='post'><table align='center' border='1'><tr><th colspan='4'>Blood Availability<tr><th>Select<th>Id<th>Name<th>Units";
	echo "<input type='hidden' name='hrequnit' value='$row[2]'>";
	echo "<input type='hidden' name='hid' value='$row[3]'>";
	while($row1 = mysql_fetch_row($rs1)) {
		echo "<tr><td><input type='checkbox' name='cid[]' value='$row1[0]'><td>$row1[0]<td>$row1[1]<td>$row1[2]";
	}
	echo "<tr><th colspan='4'><input type='submit' name='submit1' value='ISSUE'>";
	echo "</table></form>";
	} else {
		echo "<p style='text-align:center'>Sorry! No Stock available in this Blood Group</p>";
	}
} else if(isset($_POST['submit1'])) {
	if(isset($_POST['cid'])) {
		$requnit = $_POST['hrequnit'];
		$tranid = $_POST['cid'];
		$count = count($tranid);
		$aid = $_POST['hid'];

		if($count<=$requnit) {
			foreach($tranid as $t) {
			mysql_query("update bloodstore set issued='yes' where tranid=$t") or die(mysql_error());
			}
		mysql_query("update acceptorreq set issunit=issunit+$count where id=$aid") or die(mysql_error());
		} else if($count>$requnit) {
			for($i=0; $i<$requnit; $i++) {
			mysql_query("update bloodstore set issued='yes' where tranid=$tranid[$i]") or die(mysql_error());
			}
		mysql_query("update acceptorreq set issunit=issunit+$requnit where id=$aid") or die(mysql_error());
		}
	echo "<p style='text-align:center;'>Blood Issued...!<br><a href='supplytoacceptor.php'>Back</a></p>";
	} else {
		echo "<p style='text-align:center;'>Select Checkbox before submit...!</p>";
	}
}
?>
</div>
</section>
</body>
</html>