<section class="footer">
    <center>
        <h3 style="margin: 0px;">DONATE BLOOD AND SAVE LIFE!</h3>
        <h2 style="margin: 0px;">Contact Us</h2>
        <div class="icons">
            
            <h2 style="margin: 0px;"><b>Address</b></h2>
            <p style="margin: 0px;">Masjid Tawheed,No.1 Gandhi Nagar Cross Street,Anna Bus stand Backside,<br>Madurai-625001.</p>         
        </div>
<div class="footer-bottom">
  <div class="container">
     <p>                       All Rights Reserved @2022 MaduraiBloodDonors.com           <span class="pull-right"><a href=""></a></span></p>
  </div>
</div>
    </center>
</section>
<style type="text/css">
.footer {
background-color: black;
font-size: 21px;
width: 100%;
text-align: center !important;
align-content: center !important;
align-items: center !important;
align-self: center !important;
font-family: calibri;
color: white;
}

.footer h2 {
text-align: center;
font-weight: 600;
color: white;
}

.icons .fab {
color: white;
margin: 0 13px;
cursor: pointer;
padding: 18px 0;
}

.icons .fa {
color: white;
margin: 0 13px;
cursor: pointer;
padding: 18px 0;
}

.footer .icons i {
color: white;
font-size: 25px;
width: 30px;
text-align: center;
height: 30px;
padding: 15px;

}

.footer .icons i:hover {
color: #ff073a;
background-color: white;
border-radius: 50%;
padding: 15px;
}

.footer-bottom{
    width: 100%;
    height: auto;
    margin: auto;
    background: #272727;
}
.footer-bottom p{
    font-size: 14px;
    color: #fff;
    font-weight: 100;
    margin: 0;
    padding: 8.5px 0;
    text-decoration: none;
}
.footer-bottom p span{
   font-size: 14px;
}
.footer-bottom p span{
    font-size: 14px;
 }.footer-bottom p a{
     color: #fff;
     text-decoration: none;
 }
</style>

