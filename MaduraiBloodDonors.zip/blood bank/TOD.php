<?php
include "./header1.php";
?>
<html>
    <head>
        <title>Tips On Donating</title>
        <body>
            <link rel="stylesheet" type="text/css" href="TOD.css">
        <div class="title">
            <div class="animated slideInUp">
                <div class="well">
            <ul>
            <h1>Tips on donating</p></h1>
            <p>Donors have to consume good meal atleast 3hours before denoting blood.</p>
            <p>Must avoid smoking and consuming alcohol before donation and if you consumed alcohol 48 hours before donationg, you are not eligible to donate blood. </p>
            <p>The requirements before blood donation are that the donor's weight should be at least 45 kg, be at least 18 years old, and be healthy otherwise.After donating also you have to take good meal.</p>
            
            
        </ul>
        </div>
    </div>
        </div>
    </body>
</head>
</html>
