<?php
session_start();
if(!isset($_SESSION['acceptor'])) {
header("Location:photogallery.php");
}
include("db.php");
?>
<html >
<head>
       <meta charset="utf-8">
       <meta name="viewport" content="width=device-width, initial-scale=1.0">
       <link rel="stylesheet" type="text/css" href="abt.css">  
       <script src="https://kit.fontawesome.com/64d58efce2.js" ></script>
      <title> About  Us </title>

</head>
<body >
      <header>
      <div class="main">
            <div class="logo">
            <img src="logo.png">
            </div>

            <div class="nav-btn">
              <div class="nav-links">
                  <ul>
                      <li class="nav-link" style="--i: .6s">
                          <a href="homepage.php">Home</a>
                      </li>
                      <li class="nav-link" style="--i: .6s">
                          <a href="logout.php">Logout</a>
                      </li>
 </ul>
                      
                   
                    </ul>
                </div>
            </div>


<br>
<br>
<br>
<br>

          <section >
<div align='center'>
             
<?php
if(!isset($_POST['submit'])) {
?>
<form name="f" action="" method="post">
<table style="margin:auto;">
<tr>
<th>User Id
<td><input type="text" name="userid" value="<?php echo $_SESSION[acceptor]?>" readonly>
<tr>
<th class="alnr">Required BloodGroup</td>
<td>
<select name="bgroup" required>
<option value="">Select</option>
<option value="o+">O+</option>
<option value="o-">O-</option>
<option value="ab+">AB+</option>
<option value="ab-">AB-</option>
<option value="ab1+">AB1+</option>
<option value="ab1-">AB1-</option>
<option value="ab2+">AB2+</option>
<option value="ab2-">AB2-</option>
<option value="a1+">A1+</option>
<option value="a1-">A1-</option>
<option value="a2+">A2+</option>
<option value="a2-">A2-</option>
<option value="b+">B+</option>
<option value="b-">B-</option>
</select>
</td>
</tr>
<tr>
<th>Units Needed
<td><input type="text" name="units" pattern="\d+" required>
<tr>
<th colspan="2"><input type="submit" name="submit" value="Send Request">
</table>
</form>
<?php
} else {
	$userid = $_POST['userid'];
	$bgroup = $_POST['bgroup'];
	$units = $_POST['units'];
	$reqdate = date('Y-m-d',time());

	mysql_query("insert into acceptorreq (userid,reqdate,bgroup,requnit) values ('$userid','$reqdate','$bgroup',$units)") or die(mysql_error());
	echo "<br><center>Request Send<br><a href='acceptorhome.php'>Back</a></center>";
}
?>
</section>
</body>
</html>